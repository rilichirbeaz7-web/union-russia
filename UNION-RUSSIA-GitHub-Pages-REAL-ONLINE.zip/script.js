const SERVER_IP = "178.130.53.116:1461";
const MAX_PLAYERS = 50;

// Public SA:MP query API. GitHub Pages itself cannot send UDP queries,
// so the browser uses an HTTP API to read server information.
const API_URL = "https://samp-api.tk/server/" + SERVER_IP;

function setStatus(online, players = null) {
  const dots = [document.getElementById("statusDot"), document.getElementById("statusDot2")];
  const texts = [document.getElementById("statusText"), document.getElementById("statusText2")];
  dots.forEach(d => { if (!d) return; d.classList.remove("online","offline"); d.classList.add(online ? "online" : "offline"); });
  texts.forEach(t => { if (t) t.textContent = online ? "СЕРВЕР ОНЛАЙН" : "СЕРВЕР ОФФЛАЙН"; });
  if (players !== null) {
    document.getElementById("online").textContent = players;
    document.getElementById("online2").textContent = players;
  }
}

async function loadServer() {
  try {
    const response = await fetch(API_URL, { cache: "no-store" });
    if (!response.ok) throw new Error("API error");
    const data = await response.json();

    if (data.online === true) {
      const players = Number.isFinite(Number(data.players)) ? Number(data.players) : 0;
      setStatus(true, players);
    } else {
      setStatus(false, 0);
    }
  } catch (error) {
    // Do not invent an online count if the external API is unavailable.
    setStatus(false, null);
    document.getElementById("online").textContent = "—";
    document.getElementById("online2").textContent = "—";
  }
}

async function copyServerIp() {
  try {
    await navigator.clipboard.writeText(SERVER_IP);
    alert("IP сервера скопирован: " + SERVER_IP);
  } catch {
    prompt("Скопируй IP сервера:", SERVER_IP);
  }
}

document.getElementById("copyIp")?.addEventListener("click", copyServerIp);
document.getElementById("copyIp2")?.addEventListener("click", copyServerIp);

loadServer();
setInterval(loadServer, 60000);
