const SERVER_IP = "178.130.53.116:1461";
const MAX_PLAYERS_FALLBACK = 50;

/*
  ВАЖНО:
  GitHub Pages не может напрямую выполнять UDP-запросы SA:MP.
  Поэтому сюда нужно указать HTTP/HTTPS API-посредник, который возвращает JSON.
  Пример ожидаемого ответа:
  {"online":17,"maxonline":50,"online_status":true}

  Пока API_URL пустой, сайт НЕ будет выдумывать онлайн.
*/
const API_URL = "";

const statusEl = document.getElementById("status");
const playersEl = document.getElementById("players");
const maxPlayersEl = document.getElementById("maxPlayers");
const errorEl = document.getElementById("error");
const copyBtn = document.getElementById("copyBtn");
const playBtn = document.getElementById("playBtn");
const serverIpEl = document.getElementById("serverIp");

serverIpEl.textContent = SERVER_IP;
maxPlayersEl.textContent = MAX_PLAYERS_FALLBACK;

async function updateServer() {
  if (!API_URL) {
    statusEl.textContent = "Недоступен";
    statusEl.className = "status offline";
    playersEl.textContent = "—";
    errorEl.textContent = "Источник реального онлайна ещё не подключён.";
    return;
  }

  try {
    const response = await fetch(API_URL, { cache: "no-store" });
    if (!response.ok) throw new Error("HTTP " + response.status);
    const data = await response.json();

    const online = Number(data.online);
    const max = Number(data.maxonline ?? data.maxOnline ?? MAX_PLAYERS_FALLBACK);
    const isOnline = data.online_status === true || data.status === "online" || data.onlineStatus === true;

    if (!Number.isFinite(online) || !Number.isFinite(max)) throw new Error("Некорректный JSON");

    playersEl.textContent = Math.max(0, online);
    maxPlayersEl.textContent = Math.max(1, max);
    statusEl.textContent = isOnline ? "🟢 Включён" : "🔴 Выключен";
    statusEl.className = "status " + (isOnline ? "online" : "offline");
    errorEl.textContent = "";
  } catch (e) {
    statusEl.textContent = "Недоступен";
    statusEl.className = "status offline";
    playersEl.textContent = "—";
    errorEl.textContent = "Не удалось получить актуальный статус сервера.";
  }
}

copyBtn.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(SERVER_IP);
    copyBtn.textContent = "Скопировано!";
    setTimeout(() => copyBtn.textContent = "Копировать", 1500);
  } catch {
    copyBtn.textContent = "Не удалось";
    setTimeout(() => copyBtn.textContent = "Копировать", 1500);
  }
});

playBtn.addEventListener("click", () => {
  // На ПК/лаунчере можно заменить на собственный deep-link.
  window.location.href = "samp://" + SERVER_IP;
});

updateServer();
setInterval(updateServer, 30000);
